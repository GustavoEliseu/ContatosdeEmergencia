package com.gustavo.contatosdeemergencia

import android.graphics.drawable.Drawable
import android.net.Uri
import com.google.gson.annotations.Expose

class User(
    @Expose
    var nome: String,
    @Expose
    var numero: String)
